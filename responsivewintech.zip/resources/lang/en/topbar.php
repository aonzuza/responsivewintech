<?php

return [

    'company' => 'about us',
    'products' => 'products',
    'downloads' => 'downloads',
    'contactus' => 'contact us',
    'telephone' => '092-469-3000',
    // all product in sub menu
    'knobset' => 'Knob Set & Lever Handle',
    'mortiselock' => 'Mortise Lock / Profile Cylinder And Master Key Systems',
    'digitalresidentiallock' => 'Digital Resident Door Lock',
    'digitalhoteldoorlock' => 'Digital Hotel Door Lock/ Power Saving/ Relay Control/ Key Box Holder/ Key Card',
    'hinge' => 'Hinge',
    'bolt' => 'Bolt',
    'hookdoorguard' => 'Hook/ Door Guard/ Bifold Latch',
    'handle' => 'Handle',
    'knobmirorscrew' => 'Knob/ Mirror Screw',
    'doorstopper' => 'Door Stopper/ Dust Proof Strike/ Door Viewer/ Bumper/ Plate Number',
    'doorcloser' => 'Door Closer',
    'pullhandleforglassdoor' => 'Pull Handle For Glass Door',
    'panicdoor' => 'Panic Door/ Steel Door',
    'wheelrail' => 'Wheel & Rail',
    'padlock' => 'Pad Lock',
    'vecoxkirin' => 'Kirin Collection',
    'homeautomation' => 'Home Automation',
    'oem' => 'OEM/ Made-To-Order',
    'galvanizedsteelpipe' => 'Steel & Galvanized Steel Pipe',
];
