<?php

return [

    'downloadheader' => 'DOWNLOAD CATALOGUE',
    'companyprofile' => 'Company Profile & References',
    'lockandsecurity' => 'Locking & Security',
    'veco' => 'VECOxKIRIN',
    'digitallock' => 'Digital Door Lock',
    'powersaving' => 'Power Saving',
    'hinge' => 'Hinge',
    'doorcloser' => 'Door Closer',
    'panicdoor' => 'Panic Door',
    'padlock' => 'Pad Lock',
    'wheel_and_rail' => 'Wheel & Rail',
    'keycard' => 'Key Card / Key Tag',

    'productheader' => 'DOOR & WINDOW HARDWARE ACCESSORY CATALOGUE',
    'bolt' => 'Bolt',
    'hook' => 'Hook',
    'doorguard' => 'Door Guard',
    'latch' => 'Latch',
    'handle' => 'Handle',
    'knob' => 'Knob',
    'mirrorscrew' => 'Mirror Screw',
    'doorstopper' => 'Door Stopper,Dust Proof Strike& Door Viewer',
    'bumper' => 'Bumper',
    'platenumber' => 'Plate Number',

    'productmanual' => 'PRODUCT MANUAL',
    'deadboltinstall' => 'Dead Bolt Installation Guide',
    'knobset' => 'Knobsets Installation Guide',
    'leverinstall' => 'Lever Handle Installation Guide',
    'mortiseinstall' => 'Mortise Installation Guide',
    'downloadpdf' => 'Download PDF',
];
