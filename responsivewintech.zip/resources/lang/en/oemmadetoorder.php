<?php

return [

    'text' => 'We offer a one stop metalworking service starting from designing the product, creating the metal master mold, stamping using a metal stamping machine, zinc die casting, grinding using a CNC machine, polishing, and metal plating. We offer various types of metals for plating such as nickel, polished brass, antique brass, antique copper, and gold.Furthermore, our large and reliable production capacity have meant that leading international and domestic brands have placed confidence and trust in our production process for over a decade.',
];
