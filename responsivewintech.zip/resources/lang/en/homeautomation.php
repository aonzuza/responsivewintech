<?php

return [

    'header' => 'What is the Fibaro Home Automation?',
    'text' => 'It is a system that helps you easily control and monitor your home from anywhere in the world using just a mobile phone. Fibaro Home Automation is able to prevent home intrusions or accidents by alerting you in real time for whenever your doors or windows are opened or if smoke, flooding, or water leakage is detected in your home. You can also track events in your house by reviewing a history of all the actions performed by the Fibaro Home Automation system.',
];
