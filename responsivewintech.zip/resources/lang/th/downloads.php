<?php

return [

    'downloadheader' => 'ดาวน์โหลดแคตตาล็อก',
    'companyprofile' => 'ประวัติและผลงานบริษัท',
    'lockandsecurity' => 'ล็อคและอุปกรณ์',
    'veco' => 'VECOxKIRIN',
    'digitallock' => 'ดิจิตัลล็อค',
    'powersaving' => 'พาวเวอร์เซฟวิ่ง',
    'hinge' => 'บานพับ',
    'doorcloser' => 'โช้คประตู',
    'panicdoor' => 'อุปกรณ์ประตูหนีไฟ',
    'padlock' => 'แม่กุญแจ',
    'wheel_and_rail' => 'ล้อและรางเลื่อน',
    'keycard' => 'คีย์การ์ด',

    'productheader' => 'แคตตาล็อกอุปกรณ์ประตูและหน้าต่าง',
    'bolt' => 'กลอน',
    'hook' => 'ขอสับ',
    'doorguard' => 'ขอค้ำ',
    'latch' => 'ตัวล็อค',
    'handle' => 'มือจับ',
    'knob' => 'ปุ่มจับ',
    'mirrorscrew' => 'ปุ่มยึด',
    'doorstopper' => 'กันชน,แป้นกันฝุ่นและตาแมว',
    'bumper' => 'ปุ่มยางกันกระแทก',
    'platenumber' => 'ป้ายสัญลักษณ์',

    'productmanual' => 'คู่มือการติดตั้งอุปกรณ์',
    'deadboltinstall' => 'การติดตั้งชุดกุญแจ',
    'knobset' => 'การติดตั้งลูกบิดประตู',
    'leverinstall' => 'การติดตั้งชุดมือจับก้านโยก',
    'mortiseinstall' => 'การติดตั้งชุดกุญแจก้านโยกประตู',
    'downloadpdf' => 'ดาวน์โหลด PDF',
];
