<?php

return [
    'mailsent' =>'เราได้รับคำถามของคุณแล้ว !!',
    'companyname' => 'บริษัท วินเทค แมนูแฟคเจอริ่ง จำกัด',
    'address' => 'ที่อยู่',
    'addressdetails' => '35/199 หมู่ 2 ตำบล บางน้ำจืด อำเภอ เมือง จังหวัด สมุทรสาคร 74000 ประเทศไทย',
    'tel' => 'โทร:',
    'teldetails1' => '034-495-251 ถึง 6',
    'teldetails2' => '034-824-828 ถึง 9',
    'callcenter' => 'Call Center:',
    'callcenterDetails' => '092-469-3000',
    'fax' => 'แฟกซ์:',
    'faxdetails' => '034-824-831',
    'line' => 'ไลน์ไอดี:',
    'linedetails' => '@veco',
    'email' => 'อีเมล:',
    'emaildetails' => 'sale@wintechmfc.com',
    'googlemap' => 'ดูแผนที่',
    'downloadpdf' => 'ดาวน์โหลด PDF',
    'contactus' => 'ติดต่อเรา',
    //  f -> form
    'fname' => 'ชื่อ',
    'flastname' => 'นามสกุล',
    'femail' => 'อีเมล',
    'ftelephone' => 'เบอร์โทรศัพท์ (0849876547)',
    'fcompany' => 'บริษัท',
    'fprovince' => 'จังหวัด',
    'fcountry' => 'ประเทศ',
    'fproduct' => 'สินค้าที่สนใจ',
    'fsendmail' => 'ส่งอีเมล',

];
