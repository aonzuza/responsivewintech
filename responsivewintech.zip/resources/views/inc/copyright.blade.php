<div class="copyright text-center">
    Copyright © {{ date("Y") }} Wintech Manufacturing Co.,Ltd
</div>
