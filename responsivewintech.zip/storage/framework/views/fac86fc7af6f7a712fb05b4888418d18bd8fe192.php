<?php /* C:\xampp\htdocs\newwintech\resources\views/TH/steeldoor.blade.php */ ?>
<?php $__env->startSection('content'); ?>

<div class="steeldoor-page-wrapper">

      <div class="steeldoor-first-row-wrapper">

            <div class="steepdoor-page-first-wrapper">

                  <img style="width:100%;height:auto;" src="https://dummyimage.com/1920x980/" />

            </div>

      </div>

        <div class="steeldoor-second-row-wrapper">
          <div class="container-fluid">

                <div class="row">

                      <div class="col-md-6">

                            <div class="steeldoor-second-img-wrapper">
                                  <img style="width:100%;height:auto;" src="https://dummyimage.com/850x980/" />
                            </div>

                      </div>
                      <div class="col-md-6">

                              <div class="steepdoor-second-text-wrapper d-md-flex align-items-center">

                                  <p class="lead">
                                    ประตูเหล็ก ประตูเหล็กทนไฟ วงกบเหล็ก ประตูต้านแรงบิด
                                    ประตูเหล็กกันกระสุน ประตูเหล็กม้วน ประตูเหล็กม้วนทนไฟ กระจกทนไฟ
                                    กระจกกันกระสุน อุปกรณ์ประตู นึกถึงเรา VECO ผู้ได้รับการันตี เครื่องหมาย มอก.
                                    และยืนยันคุณภาพจากลูกค้า เรามีความตั้งใจรังสรรค์ผลิตภัณฑ์คุณภาพเยี่ยม ทนทาน
                                    เพื่อเป็นตัวเลือกที่ดีสำหรับคุณ
                                  </p>


                              </div>

                      </div>

                </div>

          </div>



        </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>