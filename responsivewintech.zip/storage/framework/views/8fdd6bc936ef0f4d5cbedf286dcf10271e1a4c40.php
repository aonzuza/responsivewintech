<?php /* C:\xampp\htdocs\responsivewintech\resources\views/pages/temp.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="downloads-container-wrapper">

    <div class="container-fluid">
             <!--start row  -->
               <div class="row">


                       <!-- start col -->
                        <div class="col-6 col-sm-4 col-md-3 col-lg-2 offset-lg-1">

                             <!-- content  -->
                             <div class="downloads-item-wrapper mx-auto">
                               <div class="downloads-image-wrapper">
                                 <img src="images/downloads/row1_1.png?1554091965" alt=""  />
                               </div>
                               <div class="downloads-text-wrapper">
                                 <span>
                                      ประวัติและผลงานบริษัท
                                 </span>
                               </div>
                               <div class="download-link-wrapper">
                                 <a href="images/downloads/PDF/Company_Profile_References.pdf" download="Company_Profile_References.pdf" target="_blank">ดาวน์โหลด PDF</a>
                               </div>
                             </div>

                             <!-- end content -->

                       <!-- end col -->
                       </div>

                       <!-- start col -->
                       <div class="col-6 col-sm-4 col-md-3 col-lg-2">

                             <!-- content  -->
                             <div class="downloads-item-wrapper mx-auto">
                               <div class="downloads-image-wrapper">
                                 <img src="images/downloads/row1_2.png?1554091965" alt=""  />
                               </div>
                               <div class="downloads-text-wrapper">
                                 <span>
                                                                                       ล็อคและอุปกรณ์
                                                                         </span>
                               </div>
                               <div class="download-link-wrapper">
                                 <a href="images/downloads/PDF/Locking_Security.pdf" download="Locking_Security.pdf" target="_blank">ดาวน์โหลด PDF</a>
                               </div>
                             </div>

                             <!-- end content -->

                       <!-- end col -->
                       </div>

                       <!-- start col -->
                      <div class="col-6 col-sm-4 col-md-3 col-lg-2">

                             <!-- content  -->
                             <div class="downloads-item-wrapper mx-auto">
                               <div class="downloads-image-wrapper">
                                 <img src="images/downloads/row6_1.png?1554091965" alt=""  />
                               </div>
                               <div class="downloads-text-wrapper">
                                 <span>
                                                                                       VECOxKIRIN
                                                                         </span>
                               </div>
                               <div class="download-link-wrapper">
                                 <a href="images/downloads/PDF/VECOxKIRIN.pdf" download="VECOxKIRIN.pdf" target="_blank">ดาวน์โหลด PDF</a>
                               </div>
                             </div>

                             <!-- end content -->

                       <!-- end col -->
                       </div>





                       <!-- start col -->
                      <div class="col-6 col-sm-4 col-md-3 col-lg-2">

                             <!-- content  -->
                             <div class="downloads-item-wrapper mx-auto">
                               <div class="downloads-image-wrapper">
                                 <img src="images/downloads/row1_3.png?1554091965" alt=""  />
                               </div>
                               <div class="downloads-text-wrapper">
                                 <span>
                                                                                       ดิจิตัลล็อค
                                                                         </span>
                               </div>
                               <div class="download-link-wrapper">
                                 <a href="images/downloads/PDF/Digital_Doorlock.pdf" download="Digital_Doorlock.pdf" target="_blank">ดาวน์โหลด PDF</a>
                               </div>
                             </div>

                             <!-- end content -->

                       <!-- end col -->
                       </div>






                      <!-- <div class="col-6 col-sm-4 col-md-3 col-lg-2">


                             <div class="downloads-item-wrapper mx-auto">
                               <div class="downloads-image-wrapper">
                                 <img src="images/downloads/row1_4.png?1554091965" alt=""  />
                               </div>
                               <div class="downloads-text-wrapper">
                                 <span>
                                                                                       พาวเวอร์เซฟวิ่ง
                                                                         </span>
                               </div>
                               <div class="download-link-wrapper">
                                 <a href="images/downloads/PDF/Power_Saving.pdf" download="Power_Saving.pdf" target="_blank">ดาวน์โหลด PDF</a>
                               </div>
                             </div>


                       </div> -->








                                                         <!-- end row -->
               </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>