<?php /* C:\xampp\htdocs\responsivewintech\resources\views/pages/oem.blade.php */ ?>
<?php $__env->startSection('content'); ?>

<div class="oem-page-wrapper">


          <div class="product-header-img-wrapper">

              <img style="width:100%;height:auto" src="<?php echo e(asset('images/products/product_header/oem_made_to_order.jpg').'?'.time()); ?>" />

          </div>


          <div class="container">
            <div class="row">
                  <div class="col-12 col-lg-6">
                        <img style="width:100%;height:auto" src="<?php echo e(asset('images/oem/oem.png').'?'.time()); ?>" />
                        <!-- <img style="width:100%;height:auto;" src="https://dummyimage.com/800x600/" /> -->
                  </div>
                  <div class="col-12 col-lg-6">
                        <div class="oem-text-wrapper">
                          <p>
                            <?php echo app('translator')->getFromJson('oemmadetoorder.text'); ?>
                          </p>
                        </div>
                  </div>
            </div>
          </div>


          <!-- <div class="oem-text-wrapper d-flex justify-content-end" >

              <p>
                <?php echo app('translator')->getFromJson('oemmadetoorder.text'); ?>
              </p>


          </div> -->


</div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>