<?php /* C:\xampp\htdocs\responsivewintech\resources\views/inc/footer.blade.php */ ?>
<footer class="footer-wrapper">

<div class="d-flex flex-row justify-content-center flex-even mx-auto" style="width:100%;">
      <div class="footer-first-col footer-col">
              <img class="footer-logo mb-2" src="<?php echo e(asset('images/common/logo_white.png')); ?>" />
              <div>
                  LINE ID: @VECO
                  <br>
                  Call Center: <?php echo app('translator')->getFromJson('footer.telephone'); ?>

                  <div class="d-flex footer-icons-wrapper">

                    <div class="footer-qr-wrapper bg-red">
                        <img   src="<?php echo e(asset('images/common/QRCode.png')); ?>" />
                    </div>
                    <div class="footer-social-wrapper">
                        <a target="_blank" href="https://www.facebook.com/vecohardware/" class="no-decoration"><img   src="<?php echo e(asset('images/common/fb.png')); ?>" /></a>
                        <a target="_blank" href="http://line.me/ti/p/@uuc0799v" class="no-decoration"><img   src="<?php echo e(asset('images/common/li.png')); ?>" /></a>
                        <a target="_blank" href="https://www.youtube.com/watch?v=7LUDhCxshLw&feature=youtu.be" class="no-decoration"><img   src="<?php echo e(asset('images/common/yu.png')); ?>" /></a>
                    </div>

                  </div>

              </div>
      </div>
      <div class="footer-second-col footer-col">
          <div>
              <!-- <a href="<?php echo e(asset('aboutus?area=company-profile-section-lg')); ?>"> <?php echo app('translator')->getFromJson('footer.company'); ?></a> -->
              <a href="<?php echo e(asset('aboutus')); ?>"> <?php echo app('translator')->getFromJson('footer.company'); ?></a>
          </div>
          <div>
              <a href="<?php echo e(asset('aboutus?area=certificate-section')); ?>"> <?php echo app('translator')->getFromJson('footer.certificates'); ?></a>
          </div>
          <div>
              <a href="<?php echo e(asset('aboutus?area=project-section')); ?>"> <?php echo app('translator')->getFromJson('footer.projects'); ?></a>
          </div>
          <div>
              <a href="downloads"> <?php echo app('translator')->getFromJson('footer.downloads'); ?></a>
          </div>
          <div>
              <a href="contactus"> <?php echo app('translator')->getFromJson('footer.contactus'); ?></a>
          </div>

      </div>
      <div class="footer-third-col footer-col">
          <div>
              <a href="<?php echo e(asset('products/2')); ?>"><?php echo app('translator')->getFromJson('footer.knobset'); ?> </a>
          </div>
          <div>
              <a href="<?php echo e(asset('products/3,4,5')); ?>"><?php echo app('translator')->getFromJson('footer.mortiselock'); ?></a>
          </div>
          <div>
              <!-- <a href="<?php echo e(asset('residentiallock')); ?>"><?php echo app('translator')->getFromJson('footer.digitalresidentiallock'); ?></a> -->
              <a href="<?php echo e(asset('products/41')); ?>"><?php echo app('translator')->getFromJson('footer.digitalresidentiallock'); ?></a>
          </div>
          <div>
              <a href="<?php echo e(asset('products/6,7,8,9,10')); ?>"><?php echo app('translator')->getFromJson('footer.digitalhoteldoorlock'); ?></a>
          </div>
          <div>
              <a href="<?php echo e(asset('products/11')); ?>"><?php echo app('translator')->getFromJson('footer.hinge'); ?></a>
          </div>
          <div>
              <a href="<?php echo e(asset('products/13')); ?>"><?php echo app('translator')->getFromJson('footer.bolt'); ?></a>
          </div>


      </div>
      <div class="footer-fourth-col footer-col">
          <div>
              <a href="<?php echo e(asset('products/14,15,16')); ?>"><?php echo app('translator')->getFromJson('footer.hookdoorguard'); ?></a>
          </div>

          <div>
              <a href="<?php echo e(asset('products/17')); ?>"><?php echo app('translator')->getFromJson('footer.handle'); ?></a>
          </div>
          <div>
              <a href="<?php echo e(asset('products/18,19')); ?>"><?php echo app('translator')->getFromJson('footer.knobmirorscrew'); ?></a>
          </div>
          <div>
              <a href="<?php echo e(asset('products/20,21,22')); ?>"><?php echo app('translator')->getFromJson('footer.doorstopper'); ?></a>
          </div>
          <div>
              <a href="<?php echo e(asset('products/23,24,25,26,28,29')); ?>"><?php echo app('translator')->getFromJson('footer.doorcloser'); ?></a>
          </div>
          <div>
              <a href="<?php echo e(asset('products/30,31')); ?>"><?php echo app('translator')->getFromJson('footer.pullhandleforglassdoor'); ?></a>
          </div>
          <div>
              <a href="<?php echo e(asset('products/32,33,34,35,36')); ?>"><?php echo app('translator')->getFromJson('footer.panicdoor'); ?></a>
              <!-- <a href="<?php echo e(asset('steeldoor')); ?>"><?php echo app('translator')->getFromJson('footer.panicdoor'); ?></a> -->
          </div>

      </div>
      <div class="footer-fifth-col footer-col">
        <div>
            <a href="<?php echo e(asset('products/39')); ?>"><?php echo app('translator')->getFromJson('footer.wheelrail'); ?></a>
        </div>
        <div>
            <a href="<?php echo e(asset('products/37,38')); ?>"><?php echo app('translator')->getFromJson('footer.padlock'); ?></a>
        </div>

        <div>
            <a href="<?php echo e(asset('products/40')); ?>"><?php echo app('translator')->getFromJson('footer.vecoxkirin'); ?></a>
        </div>
        <div>
            <a href="<?php echo e(asset('homeautomation')); ?>"><?php echo app('translator')->getFromJson('footer.homeautomation'); ?></a>
        </div>
        <div>
            <a href="<?php echo e(asset('oem')); ?>"><?php echo app('translator')->getFromJson('footer.oem'); ?></a>
        </div>
        <div>
            <a href="<?php echo e(asset('steel_galvanized')); ?>"><?php echo app('translator')->getFromJson('footer.galvanizedsteelpipe'); ?></a>
        </div>

      </div>
</div>

</footer>
