<?php /* C:\xampp\htdocs\newwintech\resources\views/mobile/inc/footer.blade.php */ ?>
<footer class="footer-wrapper">

<h2>

      I am mobile wrapper....

</h2>



</footer>
