<?php /* C:\xampp\htdocs\responsivewintech\resources\views/TH/test.blade.php */ ?>
<!-- <?php echo e(Session::forget('locale')); ?> -->
<?php echo e('session is '.Session::get('locale').' xsxx '); ?>

<?php echo e('result is '); ?>

<?php echo e((Session::get('locale') == 'en') ? 'th' : 'en'); ?>

