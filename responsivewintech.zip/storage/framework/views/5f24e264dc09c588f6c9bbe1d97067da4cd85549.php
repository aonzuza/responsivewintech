<?php /* C:\xampp\htdocs\newwintech\resources\views/inc/mobile/topbar.blade.php */ ?>

<!-- position fixed -->
<!-- shown when browser is less that 972px. -->
<div class="mobile-topbar">

    <div class="d-flex">

        <div class="mr-auto">
            <a href="home">
                <img class="mobile-top-bar-logo" src="<?php echo e(asset('images/common/logo_black.png')); ?>" />
            </a>
        </div>

        <div class="ml-auto">
              <a href=#>
                <img src="<?php echo e(asset('images/common/us.png')); ?>?<?php echo e(time()); ?>" class="mobile-topbar-items" />
              </a>
              <a href=#>
                  <img src="<?php echo e(asset('images/common/line_moble.png')); ?>?<?php echo e(time()); ?>" class="mobile-topbar-items" />
              </a>
              <a href=#>
                  <img src="<?php echo e(asset('images/common/menuline.png')); ?>?<?php echo e(time()); ?>" class="mobile-topbar-items sliding-menu-trigger" />
              </a>
              <a href=#>
                  <img src="<?php echo e(asset('images/common/telephone.png')); ?>?<?php echo e(time()); ?>" class="mobile-topbar-items" />
              </a>
        </div>
    </div>

</div>
