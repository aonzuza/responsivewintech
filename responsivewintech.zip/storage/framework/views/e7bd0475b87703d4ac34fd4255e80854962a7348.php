<?php /* C:\xampp\htdocs\responsivewintech\resources\views/TH/oem.blade.php */ ?>
<?php $__env->startSection('content'); ?>

<div class="oem-page-wrapper">

          <div class="oem-header-wrapper">

          <img style="width:100%;height:auto;" src="https://dummyimage.com/1920x664/" />

          </div>

          <div class="oem-text-wrapper d-flex align-items-center" >

              <p>
                <?php echo app('translator')->getFromJson('oemmadetoorder.text'); ?>
              </p>


          </div>


</div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>