<?php /* C:\xampp\htdocs\responsivewintech\resources\views/inc/copyright.blade.php */ ?>
<div class="copyright text-center">
    Copyright © <?php echo e(date("Y")); ?> Wintech Manufacturing Co.,Ltd
</div>
