<?php /* C:\xampp\htdocs\newwintech\resources\views/mobile/th/aboutus.blade.php */ ?>
<?php $__env->startSection('content'); ?>

<h2>
      about us in mobile mode

</h2>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>