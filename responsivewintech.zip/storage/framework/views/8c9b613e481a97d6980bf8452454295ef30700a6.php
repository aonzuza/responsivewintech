<?php /* C:\xampp\htdocs\responsivewintech\resources\views/inc/mobile/slidingmenu.blade.php */ ?>
<div class="sliding-menu">

  <ul class="list-unstyled components">

            <li>
                <a href="#about-submenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><?php echo app('translator')->getFromJson('footer.company'); ?></a>
                <ul class="collapse list-unstyled slide-submenu" id="about-submenu">
                    <li>
                        <!-- <a href="<?php echo e(asset('aboutus?area=company-profile-section-sm')); ?>"><?php echo app('translator')->getFromJson('footer.profile'); ?></a> -->
                        <a href="<?php echo e(asset('aboutus')); ?>"><?php echo app('translator')->getFromJson('footer.profile'); ?></a>
                    </li>
                    <li>
                        <a href="<?php echo e(asset('aboutus?area=certificate-section')); ?>"><?php echo app('translator')->getFromJson('footer.certificates'); ?></a>
                    </li>
                    <li>
                        <a href="<?php echo e(asset('aboutus?area=project-section')); ?>"><?php echo app('translator')->getFromJson('footer.projects'); ?></a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="#product-submenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><?php echo app('translator')->getFromJson('footer.products'); ?></a>
                <ul class="collapse list-unstyled slide-submenu" id="product-submenu">
                      <li><a href="<?php echo e(asset('products/2')); ?>"><?php echo app('translator')->getFromJson('topbar.knobset'); ?> </a></li>
                      <li><a href="<?php echo e(asset('products/3,4,5')); ?>"><?php echo app('translator')->getFromJson('topbar.mortiselock'); ?></a></li>

                      <!-- <li><a href="<?php echo e(asset('residentiallock')); ?>"><?php echo app('translator')->getFromJson('topbar.digitalresidentiallock'); ?></a></li> -->
                      <li><a href="<?php echo e(asset('products/41')); ?>"><?php echo app('translator')->getFromJson('topbar.digitalresidentiallock'); ?></a></li>

                      <li><a href="<?php echo e(asset('products/6,7,8,9,10')); ?>"><?php echo app('translator')->getFromJson('topbar.digitalhoteldoorlock'); ?></a></li>
                      <li><a href="<?php echo e(asset('products/11')); ?>"><?php echo app('translator')->getFromJson('topbar.hinge'); ?></a></li>
                      <li><a href="<?php echo e(asset('products/13')); ?>"><?php echo app('translator')->getFromJson('topbar.bolt'); ?></a></li>
                      <li><a href="<?php echo e(asset('products/14,15,16')); ?>"><?php echo app('translator')->getFromJson('topbar.hookdoorguard'); ?></a></li>
                      <li><a href="<?php echo e(asset('products/17')); ?>"><?php echo app('translator')->getFromJson('topbar.handle'); ?></a></li>
                      <li><a href="<?php echo e(asset('products/18,19')); ?>"><?php echo app('translator')->getFromJson('topbar.knobmirorscrew'); ?></a></li>
                      <li><a href="<?php echo e(asset('products/20,21,22')); ?>"><?php echo app('translator')->getFromJson('topbar.doorstopper'); ?></a></li>
                      <li><a href="<?php echo e(asset('products/23,24,25,26,28,29')); ?>"><?php echo app('translator')->getFromJson('topbar.doorcloser'); ?></a></li>
                      <li><a href="<?php echo e(asset('products/30,31')); ?>"><?php echo app('translator')->getFromJson('topbar.pullhandleforglassdoor'); ?></a></li>
                      <!-- <li><a href="<?php echo e(asset('steeldoor')); ?>"><?php echo app('translator')->getFromJson('topbar.panicdoor'); ?></a></li> -->
                      <li><a href="<?php echo e(asset('products/32,33,34,35,36')); ?>"><?php echo app('translator')->getFromJson('topbar.panicdoor'); ?></a></li>
                      <li><a href="<?php echo e(asset('products/39')); ?>"><?php echo app('translator')->getFromJson('topbar.wheelrail'); ?></a></li>
                      <li><a href="<?php echo e(asset('products/37,38')); ?>"><?php echo app('translator')->getFromJson('topbar.padlock'); ?></a></li>
                      <li class="slide-submenu-highlight"><a href="<?php echo e(asset('products/40')); ?>"><?php echo app('translator')->getFromJson('topbar.vecoxkirin'); ?></a></li>
                      <li class="slide-submenu-highlight"><a href="<?php echo e(asset('homeautomation')); ?>"><?php echo app('translator')->getFromJson('topbar.homeautomation'); ?></a></li>
                      <li class="slide-submenu-highlight"><a href="<?php echo e(asset('oem')); ?>"><?php echo app('translator')->getFromJson('topbar.oem'); ?></a></li>
                      <li class="slide-submenu-highlight"><a href="<?php echo e(asset('steel_galvanized')); ?>"><?php echo app('translator')->getFromJson('topbar.galvanizedsteelpipe'); ?></a></li>



                      <!-- <li><a href="<?php echo e(asset('products/30,31')); ?>"><?php echo app('translator')->getFromJson('footer.pullhandleforglassdoor'); ?></a></li>
                      <li><a href="<?php echo e(asset('products/33,34,35,36')); ?>"><?php echo app('translator')->getFromJson('footer.panicdoor'); ?></a></li>
                      <li><a href="<?php echo e(asset('products/38')); ?>"><?php echo app('translator')->getFromJson('footer.padlock'); ?></a></li>
                      <li><a href="<?php echo e(asset('products/39')); ?>"><?php echo app('translator')->getFromJson('footer.wheelrail'); ?></a></li> -->
                      <!-- <li class="slide-submenu-highlight"><a href="<?php echo e(asset('products/40')); ?>"><?php echo app('translator')->getFromJson('footer.vecoxkirin'); ?></a></li>
                      <li class="slide-submenu-highlight"><a href="<?php echo e(asset('homeautomation')); ?>"><?php echo app('translator')->getFromJson('footer.homeautomation'); ?></a></li>
                      <li class="slide-submenu-highlight"><a href="<?php echo e(asset('oem')); ?>"><?php echo app('translator')->getFromJson('footer.oem'); ?></a></li>
                      <li class="slide-submenu-highlight"><a href="<?php echo e(asset('steel_galvanized')); ?>"><?php echo app('translator')->getFromJson('footer.galvanizedsteelpipe'); ?></a></li>
                      <li class="slide-submenu-highlight"><a href="<?php echo e(asset('steeldoor')); ?>"><?php echo app('translator')->getFromJson('footer.steeldoor'); ?></a></li> -->
                </ul>
            </li>
            <li>
                <a href="<?php echo e(asset('downloads')); ?>"><?php echo app('translator')->getFromJson('footer.downloads'); ?></a>
            </li>
            <li>
                <a href="<?php echo e(asset('contactus')); ?>"><?php echo app('translator')->getFromJson('footer.contactus'); ?></a>
            </li>
        </ul>

</div>
