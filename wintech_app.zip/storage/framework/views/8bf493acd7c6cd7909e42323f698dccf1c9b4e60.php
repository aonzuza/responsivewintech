<?php /* C:\xampp\htdocs\responsivewintech\resources\views/pages/downloads.blade.php */ ?>
<?php $__env->startSection('content'); ?>

<!-- product header  -->
<div class="downloads-page-wrapper">

    <div class="container-fluid">

    <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!--  header group section -->
            <div class="container-fluid">

                  <div class="row">

                      <div class="col-12 col-lg-11 offset-lg-1">

                        <h2 class="downloads-header">

                            <?php if(Session::get('locale') == 'en'): ?>
                                    <?php echo e($group->name_EN); ?>

                            <?php else: ?>
                                    <?php echo e($group->name_TH); ?>

                            <?php endif; ?>


                        </h2>

                      </div>

                  </div>
            </div>

            <?php
              $itemCounter = 0
            ?>
            <div class="downloads-container-wrapper">
              <!--start row  -->
                <div class="row">
                  <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                      <?php if( $item->groupID == $group->groupID): ?>

                        <!-- start col -->
                        <?php if($itemCounter%5 == 0): ?>
                        <div class="col-6 col-sm-4 col-md-3 col-lg-2 offset-lg-1">
                        <?php else: ?>
                        <div class="col-6 col-sm-4 col-md-3 col-lg-2">
                        <?php endif; ?>

                              <!-- content  -->
                              <div class="downloads-item-wrapper mx-auto">
                                <div class="downloads-image-wrapper">
                                  <img src="images/downloads/<?php echo e($item->image); ?>?<?php echo e(time()); ?>" alt=""  />
                                </div>
                                <div class="downloads-text-wrapper">
                                  <span>
                                        <?php if(Session::get('locale') == 'en'): ?>
                                                <?php echo e($item->name_EN); ?>

                                        <?php else: ?>
                                                <?php echo e($item->name_TH); ?>

                                        <?php endif; ?>
                                  </span>
                                </div>
                                <div class="download-link-wrapper">
                                  <a href="images/downloads/PDF/<?php echo e($item->pdf); ?>" download="<?php echo e($item->pdf); ?>" target="_blank"><?php echo app('translator')->getFromJson('downloads.downloadpdf'); ?></a>
                                </div>
                              </div>

                              <!-- end content -->

                        <!-- end col -->
                        </div>



                        <?php $itemCounter +=1 ?>
                      <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <!-- end row -->
                </div>
            </div>


    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script type="text/javascript">


$(window).resize(function() {
    adjustImageDownloads();
});





$(document).ready(function(){

  setInterval(function(){
      // console.log('2');
    adjustImageDownloads();
  },1000);

  adjustImageDownloads();

});

function adjustImageDownloads(){


  // console.log('called');
  var count = $('.downloads-image-wrapper img').length;
  var maxHeight = 0;
  for(var i=0; i < count; i++){

     var height =  $('.downloads-image-wrapper img').eq(i).height();
     if( height > maxHeight){
       maxHeight = height;
     }
  }
  $('.downloads-image-wrapper').height(maxHeight);

  //
  // console.log('min height' + minHeight);
  //
   var totalTextWrapper = $('.downloads-text-wrapper').length;
   var maxHeight = 0;
   for(var i=0; i < totalTextWrapper; i++){

      var height =  $('.downloads-text-wrapper').eq(i).height();
      if( maxHeight < height){
        maxHeight = height;
      }
   }
   console.log('text-wrapper max height: ' + maxHeight);
   $('.downloads-text-wrapper').height(maxHeight);

}

</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>