<?php /* C:\xampp\htdocs\responsivewintech\resources\views/layouts/app.blade.php */ ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo app('translator')->getFromJson('app.companyname'); ?></title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link rel="icon" type="image/png" href="images/common/favicon.png" />

    <!-- bootstrap  -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!-- font awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">


    <!-- Google Font  -->
    <!-- <link href="https://fonts.googleapis.com/css?family=Kanit" rel="stylesheet"> -->
    <link href="https://fonts.googleapis.com/css?family=Kanit:200,300,400,500,700" rel="stylesheet">



    <link rel="stylesheet" href="<?php echo e(asset('styles/thstyle.css')); ?>" >
    <link rel="stylesheet" href="<?php echo e(asset('styles/thresponsivestyle.css')); ?>" >
    <link rel="stylesheet" href="<?php echo e(asset('styles/topbarstyle.css')); ?>" >
    <link rel="stylesheet" href="<?php echo e(asset('styles/slidingmenustyle.css')); ?>" >

    <?php if(Session::get('locale') == 'en'): ?>
    <link href="https://fonts.googleapis.com/css?family=Gothic+A1:300,400,500,600,700" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset('styles/enstyle.css')); ?>" >
    <link rel="stylesheet" href="<?php echo e(asset('styles/enresponsivestyle.css')); ?>" >
    <?php endif; ?>

    <?php echo $__env->make('inc.googleHeadScript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <?php echo $__env->yieldContent('style'); ?>
  </head>
  <body>
    <?php echo $__env->make('inc.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('inc.mobile.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('inc.mobile.slidingmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>




    <!-- <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script> -->

<script src="http://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

    <?php echo $__env->yieldContent('script'); ?>

    <script type="text/javascript">

            $("body").on("contextmenu", "img", function(e) {
                return false;
            });

              $(document).ready(function(){

                // var height = $('.mobile-topbar').height();
                //padding top + bottom
                // height += 30;
                // $('.sliding-menu').css('top',height);


                  $('.sliding-menu-trigger').click(function(){

                      var width = $('.sliding-menu').width();

                      if(width <= 0){
                        $('.sliding-menu').width('280px');
                        $('.mobile-topbar').css('left','-280px');
                      }
                      else{
                        $('.sliding-menu').width('0px');
                        $('.mobile-topbar').css('left','0');
                      }


                  });

              });

    </script>


  <?php echo $__env->make('inc.googleBodyScript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  </body>

  <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('inc.mobile.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</html>
