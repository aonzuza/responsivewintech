<?php /* C:\xampp\htdocs\newwintech\resources\views/inc/mobile/footer.blade.php */ ?>
<div class="mobile-footer">

    <div class="d-flex mobile-footer-wrapper mx-auto">

      <div class="mobile-footer-logo-wrapper align-self-center">
        <img style="width:100%;height:auto;"  src="<?php echo e(asset('images/common/logo_white.png')); ?>" />
      </div>
      <div class="mobile-footer-social-wrapper d-flex">

          <div class="mobile-footer-social-icon align-self-start">
              <img style="width:100%;height:auto;" class="footer-icon" src="<?php echo e(asset('images/common/facebook.png')); ?>" />
          </div>
          <div class="mobile-footer-social-icon align-self-start">
              <img style="width:100%;height:auto;" class="footer-icon" src="<?php echo e(asset('images/common/line.png')); ?>" />
          </div>
          <div class="mobile-footer-social-icon align-self-start">
              <img style="width:100%;height:auto;" class="footer-icon" src="<?php echo e(asset('images/common/youtube.png')); ?>" />
          </div>

      </div>
      <div class="mobile-footer-company-details">
            LineID : @VECO
            </br>
            CALL CENTER: +6692-469-3000
      </div>

    </div>

</div>
