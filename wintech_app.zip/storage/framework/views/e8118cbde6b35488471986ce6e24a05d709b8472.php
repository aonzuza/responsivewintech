<?php /* C:\xampp\htdocs\responsivewintech\resources\views/pages/steel_galvanized.blade.php */ ?>
<?php $__env->startSection('content'); ?>

<div class="steel-page-wrapper">


        <!-- <div class="steep-page-first-wrapper">

              <img style="width:100%;height:auto;" src="https://dummyimage.com/1920x840/" />

        </div> -->
        <div class="product-header-img-wrapper">

            <img style="width:100%;height:auto" src="<?php echo e(asset('images/products/product_header/steel_galvanized.jpg').'?'.time()); ?>" />

        </div>

        <div class="steep-page-second-wrapper">

                <img style="width:100%;height:auto;" src="https://dummyimage.com/1920x970/" />

        </div>



</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>