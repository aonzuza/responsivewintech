<?php /* C:\xampp\htdocs\responsivewintech\resources\views/inc/mobile/topbar.blade.php */ ?>

<!-- position fixed -->
<!-- shown when browser is less that 972px. -->
<div class="mobile-topbar">

    <div class="d-flex">

        <div class="mr-auto">
            <a href="<?php echo e(asset('home')); ?>">
                <img class="mobile-top-bar-logo" src="<?php echo e(asset('images/common/logo_black.png')); ?>" />
            </a>
        </div>

        <div class="ml-auto">
              <a href="<?php echo e(asset('/changelang')); ?>">
                <?php if(Session::get('locale') =='en'): ?>
                  <img src="<?php echo e(asset('images/common/thai.png')); ?>?<?php echo e(time()); ?>" class="mobile-topbar-items" />
                <?php else: ?>
                 <img src="<?php echo e(asset('images/common/us.png')); ?>?<?php echo e(time()); ?>" class="mobile-topbar-items" />
                <?php endif; ?>
              </a>
              <a target="_blank" href="http://line.me/ti/p/@uuc0799v">
                  <img src="<?php echo e(asset('images/common/line_moble.png')); ?>?<?php echo e(time()); ?>" class="mobile-topbar-items" />
              </a>
              <a href=#>
                  <img src="<?php echo e(asset('images/common/menuline.png')); ?>?<?php echo e(time()); ?>" class="mobile-topbar-items sliding-menu-trigger" />
              </a>
              <a href="tel:+66924693000">
                  <img src="<?php echo e(asset('images/common/telephone.png')); ?>?<?php echo e(time()); ?>" class="mobile-topbar-items" />
              </a>
        </div>
    </div>

</div>
