<?php /* C:\xampp\htdocs\responsivewintech\resources\views/inc/topbar.blade.php */ ?>


<header class="topbar">
  <!-- company info -->
  <div id="topbar-company-info" class="d-lg-flex" style="padding-left:25px;padding-top:20px;">
    <div class="mr-auto">
        <a href="home">
            <img class="top-bar-logo" src="<?php echo e(asset('images/common/logo_black.png')); ?>" />
        </a>
    </div>
    <div class="pr-4 align-self-end">

            <div>
                LINE: @VECO
            </div>
            <div>
                CALL CENTER: <?php echo app('translator')->getFromJson('topbar.telephone'); ?>
            </div>

    </div>
    <div class="pr-4 align-self-end">

            <a href="<?php echo e(asset('changelang')); ?>">EN/TH</a>
    </div>

  </div>

  <!-- menu -->
  <!-- <nav id="topbar-link-wrapper" class="navbar navbar-expand-lg navbar-light bg-white" style="padding-left:80px;padding-top:20px;"> -->
   <!-- <a class="navbar-brand" href="#">Navbar</a> -->
   <nav id="topbar-link-wrapper" class="navbar navbar-expand-lg navbar-light bg-white">
   <button class="navbar-toggler ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
     <span class="navbar-toggler-icon"></span>
   </button>

   <div class="collapse navbar-collapse" id="navbarSupportedContent">
     <ul class="navbar-nav mr-auto">
       <li class="dropdown">
         <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown"><?php echo app('translator')->getFromJson('topbar.company'); ?> <b class="caret"></b></a>
         <!-- <a class="nav-link" href="<?php echo e(asset('aboutus')); ?>"> <?php echo app('translator')->getFromJson('topbar.company'); ?> </a> -->
         <ul class="dropdown-menu multi-column columns-1">
           <div class="row">
             <div class="col-sm-12">
               <ul class="multi-column-dropdown">
                 <li><a href="<?php echo e(asset('aboutus?area=company-profile-section-lg')); ?>"><?php echo app('translator')->getFromJson('footer.profile'); ?> </a></li>
                 <li><a href="<?php echo e(asset('aboutus?area=certificate-section')); ?>"><?php echo app('translator')->getFromJson('footer.certificates'); ?></a></li>
                 <li><a href="<?php echo e(asset('aboutus?area=project-section')); ?>"><?php echo app('translator')->getFromJson('footer.projects'); ?></a></li>
               </ul>
             </div>

           </div>
         </ul>

         <!-- end  -->
       </li>
       <li class="dropdown">
           <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown"><?php echo app('translator')->getFromJson('topbar.products'); ?> <b class="caret"></b></a>
           <ul class="dropdown-menu multi-column columns-2">
             <div class="row">
               <div class="col-sm-6">
                 <ul class="multi-column-dropdown">
                   <li><a href="<?php echo e(asset('products/2')); ?>"><?php echo app('translator')->getFromJson('topbar.knobset'); ?> </a></li>
                   <li><a href="<?php echo e(asset('products/3,4,5')); ?>"><?php echo app('translator')->getFromJson('topbar.mortiselock'); ?></a></li>
                   <li><a href="<?php echo e(asset('residentiallock')); ?>"><?php echo app('translator')->getFromJson('topbar.digitalresidentiallock'); ?></a></li>
                   <li><a href="<?php echo e(asset('products/6,7,8,9,10')); ?>"><?php echo app('translator')->getFromJson('topbar.digitalhoteldoorlock'); ?></a></li>
                   <li><a href="<?php echo e(asset('products/11')); ?>"><?php echo app('translator')->getFromJson('topbar.hinge'); ?></a></li>
                   <li><a href="<?php echo e(asset('products/13')); ?>"><?php echo app('translator')->getFromJson('topbar.bolt'); ?></a></li>
                   <li><a href="<?php echo e(asset('products/14,15,16')); ?>"><?php echo app('translator')->getFromJson('topbar.hookdoorguard'); ?></a></li>
                   <li><a href="<?php echo e(asset('products/17')); ?>"><?php echo app('translator')->getFromJson('topbar.handle'); ?></a></li>
                   <li><a href="<?php echo e(asset('products/18,19')); ?>"><?php echo app('translator')->getFromJson('topbar.knobmirorscrew'); ?></a></li>


                 </ul>
               </div>
               <div class="col-sm-6">
                 <ul class="multi-column-dropdown">
                   <li><a href="<?php echo e(asset('products/20,21,22')); ?>"><?php echo app('translator')->getFromJson('topbar.doorstopper'); ?></a></li>
                   <li><a href="<?php echo e(asset('products/23,24,25,26,28,29')); ?>"><?php echo app('translator')->getFromJson('topbar.doorcloser'); ?></a></li>
                   <li><a href="<?php echo e(asset('products/30,31')); ?>"><?php echo app('translator')->getFromJson('topbar.pullhandleforglassdoor'); ?></a></li>
                   <li><a href="<?php echo e(asset('steeldoor')); ?>"><?php echo app('translator')->getFromJson('topbar.panicdoor'); ?></a></li>
                   <li><a href="<?php echo e(asset('products/39')); ?>"><?php echo app('translator')->getFromJson('topbar.wheelrail'); ?></a></li>
                   <li><a href="<?php echo e(asset('products/37,38')); ?>"><?php echo app('translator')->getFromJson('topbar.padlock'); ?></a></li>
                   <li><a href="<?php echo e(asset('products/40')); ?>"><?php echo app('translator')->getFromJson('topbar.vecoxkirin'); ?></a></li>
                   <li><a href="<?php echo e(asset('homeautomation')); ?>"><?php echo app('translator')->getFromJson('topbar.homeautomation'); ?></a></li>
                   <li><a href="<?php echo e(asset('oem')); ?>"><?php echo app('translator')->getFromJson('topbar.oem'); ?></a></li>
                   <li><a href="<?php echo e(asset('steel_galvanized')); ?>"><?php echo app('translator')->getFromJson('topbar.galvanizedsteelpipe'); ?></a></li>

                 </ul>
               </div>
             </div>
           </ul>
       </li>

       <li class="nav-item">
         <a class="nav-link" href="<?php echo e(asset('downloads')); ?>"><?php echo app('translator')->getFromJson('topbar.downloads'); ?></a>
       </li>
       <li class="nav-item">
         <a class="nav-link" href="<?php echo e(asset('contactus')); ?>"><?php echo app('translator')->getFromJson('topbar.contactus'); ?></a>
       </li>



     </ul>

   </div>
 </nav>
</header>
