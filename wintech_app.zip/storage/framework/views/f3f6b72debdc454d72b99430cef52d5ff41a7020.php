<?php /* C:\xampp\htdocs\newwintech\resources\views/mobile/inc/topbar.blade.php */ ?>
<header>

<h2>I am mobile topbar</h2>

</header>
