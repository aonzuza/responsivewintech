@extends('layouts.app')


@section('content')

<div class="steel-page-wrapper">


        <!-- <div class="steep-page-first-wrapper">

              <img style="width:100%;height:auto;" src="https://dummyimage.com/1920x840/" />

        </div> -->
        <div class="product-header-img-wrapper">

            <img style="width:100%;height:auto" src="{{asset('images/products/product_header/steel_galvanized.jpg').'?'.time()}}" />

        </div>

        <div class="steep-page-second-wrapper">

                <img style="width:100%;height:auto;" src="https://dummyimage.com/1920x970/" />

        </div>



</div>

@endsection
