<?php

return [
    'companyname' => 'WINTECH MANUFACTURING CO.,LTD.',
];
