<?php

return [
    'text' => 'Our products consists of steel doors, fireproof steel doors, steel door frames, blast resistant steel doors, bulletproof steel doors, steel roller shutter doors, fireproof steel roller shutter doors, fire rated glass, bullet-proof glass, and door accessories. The quality of our products is certified by the Thai Industrial Standard (TIS) and endorsed by our customers. We work hard to ensure that our products are of the highest quality and the best choice for you.',
];
