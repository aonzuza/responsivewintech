<?php

return [
    'mailsent' =>'We got your messages !!',
    'companyname' => 'WINTECH MANUFACTURING CO.,LTD.',
    'address' => 'Address',
    'addressdetails' => '35/199 Moo2 Tumbon Bang-namcheud,Ampher Muang Samutasakorn 74000, Thailand',
    'tel' => 'Tel:',
    'teldetails1' => '+66 34-495-251-6',
    'teldetails2' => '+66 34-824-828-9',
    'callcenter' => 'Call Center:',
    'callcenterDetails' => '+66 92-469-3000',
    'fax' => 'Fax:',
    'faxdetails' => '+66 34-824-831',
    'line' => 'Line ID:',
    'linedetails' => '@veco',
    'email' => 'Email:',
    'emaildetails' => 'sale@wintechmfc.com',
    'googlemap' => 'Enlarge Map',
    'downloadpdf' => 'Download PDF',
    'contactus' => 'Contact Form',
    //  f -> form
    'fname' => 'Name',
    'flastname' => 'Last Name',
    'femail' => 'Email',
    'ftelephone' => 'Telephone (0849876547)',
    'fcompany' => 'Company',
    'fprovince' => 'Province',
    'fcountry' => 'Country',
    'fproduct' => 'Product Interest',
    'fsendmail' => 'Submit',

];
