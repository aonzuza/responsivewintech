<?php

return [
    'japan1' => '精巧にデザインされた製品で玄関やドアを飾り、 魅力的な扉まわりを実現しませんか?',
    'japan2' => '私たちは、最高の素材を使い、機能性に優れたデザイン性の 高い製品で、お客様のご期待にお応えします。',
    'japan3' => '「シンプル」「スマート」「スタイリッシュ」。',
    'japan4' => '私たちの魅力的な製品ラインアップから、お好みの組み合せ をお楽しみください。',
    'textheader' =>'Why can\'t hardware be stylish?',
    'text1' => 'Let\'s dress up your door with our crafted items. We choose the best materials, then meticulously design and produce the products to meet your expectation in both functionality and style. Enjoy mixing and matching with a variety of sample, smart and stylish products. Have fun!!',
];
