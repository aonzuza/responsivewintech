<?php

return [
    'companyname' => 'บริษัท วินเทค แมนูแฟคเจอริ่ง จำกัด',
];
