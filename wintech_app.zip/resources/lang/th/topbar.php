<?php

return [

    'company' => 'องค์กรของเรา',
    'products' => 'ผลิตภัณฑ์',
    'downloads' => 'ดาวน์โหลด',
    'contactus' => 'ติดต่อเรา',
    'telephone' => '092-469-3000',
    // all product in sub menu
    'knobset' => 'ลูกบิดและก้านโยก',
    'mortiselock' => 'มอร์ติสล็อค / ไส้กุญแจและระบบมาสเตอร์คีย์',
    'digitalresidentiallock' => 'ดิจิตอลล็อคสำหรับบ้านพักทั่วไป',
    'digitalhoteldoorlock' => 'ดิจิตอลล็อคสำหรับโรงแรม/ พาวเวอร์เซฟวิ่ง/ รีเลย์/ ช่องเสียบการ์ด/ คีย์การ์ด',
    'hinge' => 'บานพับ',
    'bolt' => 'กลอน',
    'hookdoorguard' => 'ขอสับ/ ขอค้ำ/ ตัวล็อค',
    'handle' => 'มือจับ',
    'knobmirorscrew' => 'ปุ่มจับ/ ปุ่มกระจก',
    'doorstopper' => 'กันชน/ แป้นกันฝุ่น/ ตาแมว/ ปุ่มยางกันกระแทก/ ป้ายสัญลักษณ์',
    'doorcloser' => 'โช้คประตู',
    'pullhandleforglassdoor' => 'อุปกรณ์กระจก/ มือจับบานกระจก',
    'panicdoor' => 'อุปกรณ์ประตูหนีไฟ',
    'wheelrail' => 'ล้อและรางเลื่อน',
    'padlock' => 'แม่กุญแจ',
    'vecoxkirin' => 'VecoxKirin Collections',
    'homeautomation' => 'ระบบบ้านอัจฉริยะ',
    'oem' => 'OEM/ ผลิตตามสั่ง',
    'galvanizedsteelpipe' => 'ท่อเหล็กและแป๊ปน้ำ',

];
